name = '전북은행 고객님, '
greeting = '환영합니다!'
print(name,greeting)
print(name + greeting)


# 변수에 문자담기

print(name, greeting)
print(greeting, name)

text = name + '님, ' + greeting + '하세요'
print(text)
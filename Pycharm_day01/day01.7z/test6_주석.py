print ("Hello World!")
print ("Hello World!")    # 이것도 라인 코멘트입니다
print ("Hello World!")    # 이것도 라인 코멘트입니다

# First comment
a = 12    # second comment
# a 값을 출력해보세요!

print(a)
b = '파이선의 주석은 샵기호(#)로 시작합니다.'
print(b)
# 마지막 라인입니다.
12
파이선의 주석은 샵기호(#)로 시작합니다.
# Comment, 한줄주석과 블럭주석

"""
블럭주석, 
즉 멀티라인의 주석문은 따옴표(''' ''') 3개
"""
# 한줄주석문은 샵(#)기호

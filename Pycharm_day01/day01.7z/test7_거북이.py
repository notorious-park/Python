import turtle

input('엔터를 치면 거북이를 소개합니다.^^')
turtle.shape('turtle')

input('엔터를 치면 앞으로 전진합니다.^^')
turtle.forward(100)

input('엔터를 치면 한번 더 앞으로 전진합니다.^^')
turtle.forward(100)

input('엔터를 치면 왼쪽으로 전진합니다.^^')
turtle.left(90)
turtle.forward(100)

input('엔터를 치면 오른쪽으로 전진합니다.^^')
turtle.right(90)
turtle.forward(150)

input('엔터를 치면 오른쪽으로 전진합니다.^^')
turtle.right(90)
turtle.forward(300)

input('엔터를 치면 오른쪽으로 전진합니다.^^')
turtle.right(90)
turtle.forward(150)

input('엔터를 치면 오른쪽으로 전진합니다.^^')
turtle.right(90)
turtle.forward(100)

input('엔터를 치면 왼쪽으로 전진합니다.^^')
turtle.right(90)
turtle.forward(150)

turtle.done()
#끝
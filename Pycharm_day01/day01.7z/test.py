for i in range(20):
    print (i,i**2)

for j in range(10):
    print(j)
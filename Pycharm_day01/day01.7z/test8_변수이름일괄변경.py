num01 = 111
num2 = 222

sum = num01 + num2
print(sum)

#해당 변수 오른쪽 마우스 - Refactor - rename

#추가 단축키
#바로 실행 : ctrl + shift + f10
#파일이름 변경 : shift + f6